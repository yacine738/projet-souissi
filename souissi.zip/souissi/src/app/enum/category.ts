export enum Category {
    SelfImprovement = "self-improvement",
    Romance = "romance",
    SciFi = "science-fiction",
    Action = "action",
    Adventure = "adventure",
    Mystery = "mystery",
    Thriller = "thriller",
  }
  