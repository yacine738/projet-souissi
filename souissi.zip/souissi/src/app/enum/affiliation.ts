import { Departement } from "./departements";

export class Affiliation {
    
    constructor(
        public departement:Departement
    ){}
}
