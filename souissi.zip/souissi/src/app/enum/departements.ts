export enum Departement{
    IT="TI",
    MGT="management"
 }
